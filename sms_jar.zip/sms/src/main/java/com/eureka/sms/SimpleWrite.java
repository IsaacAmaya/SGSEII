package com.eureka.sms;

import java.io.IOException;
import java.io.OutputStream;

class SimpleWrite implements Runnable
{
    static String messageString = "ATE0\r";
    static String messageString1 = "AT+CMGF=1\r";
    static String messageString2 = "AT+CSCA=\"+584145559731\"\r";
    static String messageString33 = "AT+CNMI=1,2,0,0,0\r";
    static OutputStream outputStream;
    Thread t;
    SimpleWrite(OutputStream outputStream)
    {
        //System.out.println("in the main constructor");
        this.outputStream=outputStream;
        t=new Thread(this);
        t.run();
    }
    public void run()
    {
        try {
            Thread.sleep(1000);
            outputStream.write(messageString.getBytes());
            Thread.sleep(500);
            outputStream.write(messageString1.getBytes());
            Thread.sleep(500);
            outputStream.write(messageString2.getBytes());
            Thread.sleep(10000);
            outputStream.write(messageString33.getBytes());
        }catch(IOException e) {System.out.println(e);}
        catch(InterruptedException e) {}
        while(true)
        {

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}