package com.eureka.sms;

import sun.net.www.protocol.http.HttpURLConnection;

import java.io.*;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.*;
import javax.comm.*;

public class SimpleRead implements Runnable, SerialPortEventListener {
    static CommPortIdentifier portId;
    static Enumeration portList;
    static OutputStream outputStream;
    InputStream inputStream;
    SerialPort serialPort;
    Thread readThread;


    static String messageString1 = "AT";
    //static String messageString2 = "AT+CPIN=\"7078\"";
    static String messageString3 = "AT+CMGF=1";
    static String messageString4 = "AT+CMGS=\"+584145559731\"";
    static String messageString5 = "Mensaje recibido en breve procesaremos su peticion";
    static char enter = 13;
    static char CTRLZ = 26;




    public static void main(String[] args)
    {

        portList = CommPortIdentifier.getPortIdentifiers();

        while (portList.hasMoreElements())
        {
            //System.out.println("-");
            portId = (CommPortIdentifier) portList.nextElement();
            //System.out.println(portId.getName());
            if (portId.getPortType() == CommPortIdentifier.PORT_SERIAL)
            {
                //System.out.println(portId.getName());
                //if (portId.getName().equals("COM1"))   //ESTE ES EL PUERTO QUE SE VA A USAR EN EL SERVIDOR DEBES DESCOMENTARLO ANTES DE CREAR EL ARCHIVO SMS.JAR Y COMENTAR EL OTRO
                if (portId.getName().equals("COM4"))
                {
                    SimpleRead reader = new SimpleRead();
                }
            }
        }

    }
    public SimpleRead() {
        try {
            serialPort = (SerialPort) portId.open("SimpleReadApp", 2000);
        } catch (PortInUseException e)
        {
            System.out.println("Port Already in Use");
            return;
        }
        try {
            serialPort.setSerialPortParams(9600,
                    SerialPort.DATABITS_8,
                    SerialPort.STOPBITS_1,
                    SerialPort.PARITY_NONE);
        } catch (UnsupportedCommOperationException e) {}
        try
        {
            outputStream = serialPort.getOutputStream();
        } catch (IOException e) {}
        try {
            inputStream = serialPort.getInputStream();
        } catch (IOException e) {}
        try {
            serialPort.addEventListener(this);
        } catch (TooManyListenersException e) {}
        serialPort.notifyOnDataAvailable(true);
        readThread = new Thread(this);
        readThread.setDaemon(true);
        readThread.start();
    }
    public void run()
    {
        System.out.println("Listo para Recibir Mensajes");


        SimpleWrite sw1= new SimpleWrite(outputStream);
        while(true)
        {
            try {

                Thread.sleep(2000);
            } catch (InterruptedException e) {
                serialPort.close();
            }
        }
    }
    public void serialEvent(SerialPortEvent event) {
        switch(event.getEventType()) {
            case SerialPortEvent.BI:
            case SerialPortEvent.OE:
            case SerialPortEvent.FE:
            case SerialPortEvent.PE:
            case SerialPortEvent.CD:
            case SerialPortEvent.CTS:
            case SerialPortEvent.DSR:
            case SerialPortEvent.RI:
            case SerialPortEvent.OUTPUT_BUFFER_EMPTY:
                break;
            case SerialPortEvent.DATA_AVAILABLE:
                byte[] readBuffer = new byte[220];
                try {
                    String respuestaconsulta="";
                    int contador=0;
                    while (inputStream.available()>0) {
                        contador++;
                        System.out.println("Comprobando "+contador);
                        int numBytes = inputStream.read(readBuffer);

                        respuestaconsulta = recibirdata();//FUNCION PARA CONSULTAR CAMBIOS EN  LA BASE DE DATOS
                        //System.out.println("RESULTADO "+respuestaconsulta.length());
                    }
                    String str= new String(readBuffer);
                    //System.out.println("RESULTADO "+new String(readBuffer).length());


                    //System.out.println("RESULTADO "+respuestaconsulta);

                    int cant=respuestaconsulta.length();

                    //System.out.println("VALOR DE CANT "+cant);

                    if(cant==2) {
                        System.out.println("NO EXISTEN PEDIDOS POR NOTIFICAR");

                    }else if(cant>2){

                        String primerarreglo = respuestaconsulta.replace("{\"data\":[", "").replace("]}", "").replace("],[", "]/[").replace("\",", "/").replace("\"", "");
                        //System.out.println("REPLACE " + primerarreglo);
                        //System.out.println("REPLACE " + primerarreglo.toString().length());

                        String arreglo = primerarreglo.toString();
                        String[] arreglo2 = arreglo.split("/");
                        System.out.println("TOTAL PEDIDOS PENDIENTES POR NOTIFICAR " + arreglo2.length);

                        for (Integer i = 0; i < arreglo2.length; i++) {
                            System.out.println("PEDIDO NRO " + i + " " + arreglo2[i]);

                            String[] arreglo3 = arreglo2[i].split(",");
                            //System.out.println("Datos contenidos "+arreglo3.length);

                            String idpedido = "";
                            String estatus = "";
                            String telefono = "";

                            //System.out.println("INICIA LA CLASIFICACION");
                            for (Integer o = 0; o < arreglo3.length; o++) {

                                //System.out.println("Pedido pendiente "+i+" Contador 2do "+o+" Valor de la posicion "+arreglo3[o]);
                                idpedido = arreglo3[0];
                                estatus = arreglo3[1];
                                telefono = arreglo3[2];
                                //System.out.println(telefono);


                            }
                            String messageString4Otro = "";
                            String messageString5Otro = "";
                            int intEstatus = Integer.parseInt(estatus);
                            //int intTelefono = Integer.parseInt(telefono);
                            telefono = "+58" + telefono.substring(telefono.indexOf("0") + 1);
                            String newEstatus ="";
                            //System.out.println(telefono);
                            if (intEstatus == 2) {
                               // System.out.println("POR RECHAZAR");
                                //System.out.println("Nro pedido por rechazar " + i + " datos de pedido " + estatus + "," + idpedido + "," + telefono);
                                messageString4Otro = "AT+CMGS=\"" + telefono + "\"";
                                messageString5Otro = "Estimado Cliente NO hemos procesado su pedido por favor verifique la informacion suministrada ";
                                newEstatus= "0";
                                //System.out.println(messageString5Otro);

                            }
                            if (intEstatus == 3) {
                                //System.out.println("POR CONFIRMAR");
                                //System.out.println("Nro pedido por confirmar " + i + " datos de pedido " + estatus + "," + idpedido + "," + telefono);
                                messageString4Otro = "AT+CMGS=\"" + telefono + "\"";
                                messageString5Otro = "Estimado Cliente hemos confirmado exitosamente su pago, en breve recibira su pedido";
                                newEstatus= "4";
                                //System.out.println(messageString5Otro);
                            }
                            String cambiarestatus = "";
                            try {
                                //System.out.println("Preparando Respuesta");
                                outputStream.write((messageString1 + enter).getBytes());
                                Thread.sleep(100);
                                outputStream.flush();
                                ///outputStream.write((messageString2 + enter).getBytes());
                                Thread.sleep(100);
                                outputStream.flush();
                                outputStream.write((messageString3 + enter).getBytes());
                                Thread.sleep(100);
                                outputStream.flush();
                                outputStream.write((messageString4Otro + enter).getBytes());
                                Thread.sleep(100);
                                outputStream.flush();
                                outputStream.write((messageString5Otro + CTRLZ).getBytes());
                                outputStream.flush();
                                Thread.sleep(100);
                                System.out.println("Enviando Mensaje "+messageString5Otro+" al " + telefono);

                                cambiarestatus = enviarid(idpedido,newEstatus);
                                if(cambiarestatus.length()!=15){
                                    System.out.println("ERROR AL CAMBIAR EL ESTATUS");
                                } else {
                                    System.out.println("CAMBIO DE ESTATUS REALIZADO CON EXITO");
                                }
                                Thread.sleep(3000);
                                //outputStream.close();
                                //serialPort.close();
                                //System.out.println("Port COM cerrado");
                            } catch (IOException e) {
                                e.printStackTrace();
                                //System.out.println("ENTRO EN LA SECCION DE NO EXCEPTION");
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }


                        }
                    }

                    //if(str.indexOf("OK")!=-1 )
                        //System.out.println("ok is there");
                    //if(str.indexOf(">")!=-1 )
                        //System.out.println("now enter the message");
                    //if(str.indexOf("ERROR")!=-1 )
                        //System.out.println("ERROR is there");
                    if(str.indexOf("CMGS")!=-1 )
                        System.out.println("Mensaje Enviado");

                    if(str.indexOf("CMT") !=-1)
                    {
                        System.out.println("#################### > Nuevo mensaje Recibido < ####################" );
                        System.out.println(new String(readBuffer));

                        String msj = new String(readBuffer);
                        String numero  = msj.substring(0,msj.indexOf(",")).replace("+CMT: \"","").replace("\"","");
                        numero = "+58"+numero.substring(numero.indexOf("0")+1);
                        String messageString4Nuevo =  "AT+CMGS=\""+numero+"\"";

                        String contenido =msj.replace("+CMT: \"","").replace("\",,\"",",").replace(",",",").replace("\"",",").replace(" ",",").replaceAll("[\n\r]","");
                        String[] msjarray;
                        String datos = String.valueOf(contenido);
                        msjarray = datos.split(",");

                        Integer cantidad =0;
                        cantidad = msjarray.length;
                        //System.out.println(contenido);
                        //System.out.println(cantidad);
                        String messageString5Nuevo="";

                        if(cantidad==7) {


                            String remitente = msjarray[0];
                            String fecha = msjarray[1];
                            fecha = "20"+fecha;
                            String codigocliente = msjarray[3];
                            String banco = msjarray[4];
                            String referencia = msjarray[5];
                            String monto = msjarray[6];

                            String respuestapeticion = enviardata(remitente,fecha,codigocliente,banco,referencia,monto);


                            //System.out.println("QUE MUESTRA -> "+respuestapeticion.length()+" <- AQUIIII" );


                            if(respuestapeticion.length()==15){
                                //System.out.println("Ha registrado exitosamente");
                                messageString5Nuevo = "Mensaje recibido correctamente en breve procesaremos su peticion";
                                System.out.println("REGISTRO EXITOSO");
                                /*System.out.println("Enviado desde -> "+remitente );
                                System.out.println("Fecha Solicitud -> "+fecha );
                                System.out.println("Codigo Cliente-> "+codigocliente);
                                System.out.println("Banco -> "+banco );
                                System.out.println("Referencia -> "+referencia );
                                System.out.println("Monto a Recargar -> "+monto );
                                System.out.println(messageString5Nuevo);*/



                            }else if (respuestapeticion.length()>15){
                                //System.out.println("No ha podido registrarse");
                                messageString5Nuevo = "Estimado Cliente por favor verifique el codigo de cliente y banco enviados";
                                System.out.println(messageString5Nuevo);
                                System.out.println("REGISTRO NO REALIZADO");

                            }else {
                                messageString5Nuevo = "Disculpe la molestia por favor intente mas tarde gracias";
                            }


                        } else{
                            messageString5Nuevo = "Estimado Cliente el mensaje enviado no posee el Formato Correcto";

                        }

                        try {
                            //System.out.println("Preparando Respuesta");
                            outputStream.write((messageString1 + enter).getBytes());
                            Thread.sleep(100);
                            outputStream.flush();
                            ///outputStream.write((messageString2 + enter).getBytes());
                            Thread.sleep(100);
                            outputStream.flush();
                            outputStream.write((messageString3 + enter).getBytes());
                            Thread.sleep(100);
                            outputStream.flush();
                            outputStream.write((messageString4Nuevo + enter).getBytes());
                            Thread.sleep(100);
                            outputStream.flush();
                            outputStream.write((messageString5Nuevo + CTRLZ).getBytes());

                            outputStream.flush();
                            Thread.sleep(100);
                            System.out.println("Enviando Mensaje "+messageString5Nuevo);
                            Thread.sleep(3000);
                           /* outputStream.close();
                            serialPort.close();*/
                            //System.out.println("Port COM cerrado");
                        } catch (IOException e) {
                            e.printStackTrace();
                            //System.out.println("ENTRO EN LA SECCION DE NO EXCEPTION");
                        }catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }

                } catch (IOException e) {}
                break;
        }
    }

    public static String enviardata(String remitente, String fecha, String codigocliente, String banco, String referencia, String monto) {
        //System.out.println("Entro Aqui");

        String salida = "";
        String requestString = "http://192.168.20.15/sms/Pedidosms";  //ESTE ES LA RUTA PARA CONSULTAR EN EL SERVIDOR DEBES DESCOMENTAR Y COMENTAR EL OTRO PARA CREAR EL PAQUETE
        //String requestString = "http://localhost:8080/sms/Pedidosms";
        String json = "operacion=1&r="+remitente+"&f="+fecha+"&cc="+codigocliente+"&b="+banco+"&ref="+referencia+"&m="+monto+"&estatus=1&tipo=1&not=0";

        //System.out.println(json);

        //send request
        URL url;
        try {
            url = new URL(requestString);
            //System.out.println("Entro en la URL");
            try {
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setDoOutput(true);
                try {
                    conn.setRequestMethod("POST");
                    //System.out.println("Entro en el Metodo para enviar");

                } catch (ProtocolException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                //System.out.println("ha salido de enviar por el metodo");

                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");
                conn.setRequestProperty("User-Agent", "Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:39.0) Gecko/20100101 Firefox/39.0");
                //conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                conn.setConnectTimeout(8000);
                OutputStream os = conn.getOutputStream();
                os.write(json.getBytes());
                //System.out.println(os);
                os.flush();
                int responseCode = conn.getResponseCode();
                //System.out.println(responseCode);
                //get result if there is one
                if(responseCode == 200)
                {
                   // System.out.println("SI LA RESPUESTA ES CORRECTA ENTRA AQUI");
                    String result = "";
                    BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
                    String output;
                    while((output = br.readLine()) != null)
                    {
                        result += output;
                    }
                    salida = result;
                }

               // salida=Integer.toString(responseCode);

            } catch (IOException e1) {
                // TODO Auto-generated catch block
                //e1.printStackTrace();
            }
        } catch (MalformedURLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }


        return salida;
    }



    public static String recibirdata() {
        //System.out.println("Entro Aqui");

        String salida = "";

        String requestString = "http://192.168.20.15/sms/Pedidosms";  //ESTE ES LA RUTA PARA CONSULTAR EN EL SERVIDOR DEBES DESCOMENTAR Y COMENTAR EL OTRO PARA CREAR EL PAQUETE
        //String requestString = "http://localhost:8080/sms/Pedidosms";
        String json = "operacion=4&desdesms=1";

        //System.out.println(json);

        //send request
        URL url;
        try {
            url = new URL(requestString);
            //System.out.println("Entro en la URL");
            try {
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setDoOutput(true);
                try {
                    conn.setRequestMethod("POST");
                    //System.out.println("Entro en el Metodo para enviar");

                } catch (ProtocolException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                    System.out.println("Entro a la excepcion");
                }
                //System.out.println("ha salido de enviar por el metodo");

                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");
                conn.setRequestProperty("User-Agent", "Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:39.0) Gecko/20100101 Firefox/39.0");
                //conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                conn.setConnectTimeout(8000);

                OutputStream os = conn.getOutputStream();

                os.write(json.getBytes());

                os.flush();
                int responseCode = conn.getResponseCode();

                //get result if there is one
                if(responseCode == 200)
                {
                   // System.out.println("VALIDO");
                    String result = "";
                    BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
                    String output;
                    while((output = br.readLine()) != null)
                    {
                        result += output;
                    }
                    salida = result;
                }

                // salida=Integer.toString(responseCode);

            } catch (IOException e1) {
                // TODO Auto-generated catch block
                System.out.println("NO HAY RESPUESTA DEL SERVIDOR");
                //e1.printStackTrace();
            }
        } catch (MalformedURLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        //System.out.println("Resultado final"+salida);
        return salida;
    }



    public static String enviarid(String idpedido, String newEstatus) {
        //System.out.println("Entro Aqui "+idpedido);

        String salida = "";

        String requestString = "http://192.168.20.15/sms/Pedidosms";  //ESTE ES LA RUTA PARA CONSULTAR EN EL SERVIDOR DEBES DESCOMENTAR Y COMENTAR EL OTRO PARA CREAR EL PAQUETE
        //String requestString = "http://localhost:8080/sms/Pedidosms";
        String json = "operacion=2&desdesms=1&idpedido="+idpedido+"&estatus="+newEstatus;

        //System.out.println(json);

        //send request
        URL url;
        try {
            url = new URL(requestString);
            //System.out.println("Entro en la URL");
            try {
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setDoOutput(true);
                try {
                    conn.setRequestMethod("POST");
                    //System.out.println("Entro en el Metodo para enviar");

                } catch (ProtocolException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                //System.out.println("ha salido de enviar por el metodo");

                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");
                conn.setRequestProperty("User-Agent", "Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:39.0) Gecko/20100101 Firefox/39.0");
                //conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                conn.setConnectTimeout(8000);
                OutputStream os = conn.getOutputStream();
                os.write(json.getBytes());
                //System.out.println(os);
                os.flush();
                int responseCode = conn.getResponseCode();
                //System.out.println(responseCode);
                //get result if there is one
                if(responseCode == 200)
                {
                    // System.out.println("VALIDO");
                    String result = "";
                    BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
                    String output;
                    while((output = br.readLine()) != null)
                    {
                        result += output;
                    }
                    salida = result;
                }

                // salida=Integer.toString(responseCode);

            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        } catch (MalformedURLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        //System.out.println("Resultado final"+salida);
        return salida;
    }




}

