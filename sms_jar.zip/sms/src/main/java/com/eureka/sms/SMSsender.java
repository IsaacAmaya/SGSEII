package com.eureka.sms;

import javax.comm.CommPortIdentifier;
import javax.comm.PortInUseException;
import javax.comm.SerialPort;
import javax.comm.UnsupportedCommOperationException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;

//import gnu.io.*;

public class SMSsender {
    static Enumeration portList;
    static CommPortIdentifier portId;
    static String messageString1 = "AT";
    //static String messageString2 = "AT+CPIN=\"7078\"";
    static String messageString3 = "AT+CMGF=1";
    static String messageString4 = "AT+CMGS=\"+584245114573\"";
    static String messageString5 = "Tengo mi linea pegada a la computadora haciendo unas pruebas con respuestas automaticas, yo le escribo orita espera que lo desconecte";
    static SerialPort serialPort;
    static OutputStream outputStream;
    static InputStream inputStream;
    static char enter = 13;

    static char CTRLZ = 26;

    public static void main(String[] args) throws InterruptedException {
        portList = CommPortIdentifier.getPortIdentifiers();


        while (portList.hasMoreElements()) {

            portId = (CommPortIdentifier) portList.nextElement();
            if (portId.getPortType() == CommPortIdentifier.PORT_SERIAL) {


                System.out.println(portId.getName());
                if (portId.getName().equals("COM4")) {
                    //System.out.println("Entro");
                    try {
                        serialPort = (SerialPort)
                                portId.open("COM4", 2000);

                    } catch (PortInUseException e) {
                        System.out.println("Error Puerto en uso");
                    }
                    try {
                        outputStream = serialPort.getOutputStream();
                        inputStream = serialPort.getInputStream();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    try {
                        serialPort.setSerialPortParams(9600,
                                SerialPort.DATABITS_8,
                                SerialPort.STOPBITS_1,
                                SerialPort.PARITY_NONE);
                    } catch (UnsupportedCommOperationException e) {
                        e.printStackTrace();
                    }
                    try {
                        System.out.println("Preparando Mensaje");
                        outputStream.write((messageString1 + enter).getBytes());


                        Thread.sleep(100);
                        outputStream.flush();

                        ///outputStream.write((messageString2 + enter).getBytes());

                        Thread.sleep(100);
                        outputStream.flush();

                        outputStream.write((messageString3 + enter).getBytes());

                        Thread.sleep(100);
                        outputStream.flush();


                        outputStream.write((messageString4 + enter).getBytes());

                        Thread.sleep(100);
                        outputStream.flush();

                        outputStream.write((messageString5 + CTRLZ).getBytes());

                        outputStream.flush();
                        Thread.sleep(100);


                        System.out.println("Enviando Mensaje");
                        Thread.sleep(3000);


                        outputStream.close();
                        serialPort.close();
                        System.out.println("Port COM cerrado");

                    } catch (IOException e) {
                        e.printStackTrace();
                        System.out.println("ENTRO EN LA SECCION DE NO EXCEPTION");
                    }
                }
            }
        }
    }
}